const $ = (sel) => document.querySelector(sel);
const api = (path, opts) => fetch(path, opts).then(r => {
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json().catch(_=> ({}));
});

let beansCache = [];

async function loadBeans(q="") {
  const url = q ? `/api/beans?q=${encodeURIComponent(q)}` : `/api/beans`;
  const beans = await api(url);
  beansCache = beans;
  renderBeans(beans);
  fillOrderSelect(beans);
  if (beans.length && !$("#details").dataset.hasSelection) showDetails(beans[0]);
}

function renderBeans(beans) {
  const list = $("#beans");
  list.innerHTML = "";
  beans.forEach(b => {
    const div = document.createElement("div");
    div.className = "bean";
    div.innerHTML = `
      <img src="${b.image}" alt="${b.name}"/>
      <div><strong>${b.name}</strong></div>
      <div class="muted">${b.country} • ${b.colour} • £${b.cost.toFixed(2)}</div>
    `;
    div.onclick = () => showDetails(b);
    list.appendChild(div);
  });
}

function showDetails(b) {
  const d = $("#details");
  d.dataset.hasSelection = "1";
  d.innerHTML = `
    <img src="${b.image}" alt="${b.name}"/>
    <h3>${b.name}</h3>
    <div class="muted">${b.country} • ${b.colour}</div>
    <p>${b.description}</p>
    <div><span class="badge">£${b.cost.toFixed(2)}</span></div>
  `;
  const sel = $("#order-bean");
  if (sel && [...sel.options].some(o => +o.value === b.id)) sel.value = b.id;
}

async function loadBOTD() {
  const botd = await api("/api/botd");
  const b = botd.bean;
  $("#botd-content").innerHTML = `
    <div class="bean-row">
      <img src="${b.image}" alt="${b.name}"/>
      <div>
        <div><strong>${b.name}</strong></div>
        <div class="muted">${b.country} • ${b.colour}</div>
        <div class="badge">£${b.cost.toFixed(2)}</div>
      </div>
    </div>
  `;
}

function fillOrderSelect(beans) {
  const sel = $("#order-bean");
  sel.innerHTML = beans.map(b => `<option value="${b.id}">${b.name} (£${b.cost.toFixed(2)})</option>`).join("");
}

async function placeOrder(e) {
  e.preventDefault();
  const payload = {
    beanId: +$("#order-bean").value,
    customerEmail: $("#order-email").value,
    quantity: +$("#order-qty").value
  };
  try {
    const res = await api("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    $("#order-result").textContent = `Order #${res.id} placed for ${res.quantity} × ${res.unitPrice.toFixed(2)} (total £${(res.quantity*res.unitPrice).toFixed(2)})`;
  } catch (err) {
    $("#order-result").textContent = `Order failed: ${err.message}`;
  }
}

$("#search").addEventListener("input", (e) => loadBeans(e.target.value));
$("#order-form").addEventListener("submit", placeOrder);
$("#refresh-botd").addEventListener("click", loadBOTD);

loadBeans().then(loadBOTD);
