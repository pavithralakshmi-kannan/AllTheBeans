Run 'dotnet ef migrations add Initial' here to scaffold migrations.
